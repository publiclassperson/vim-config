If you discover a security issue in this repo, please submit it through the
[GitHub Security Bug Bounty](https://hackerone.com/github).

Thanks for helping make GitHub Copilot safe for everyone.
