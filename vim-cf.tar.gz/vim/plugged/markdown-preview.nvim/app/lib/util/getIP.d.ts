export declare function getIP(): string;
