declare const _default: {
    '@chemzqm/neovim': any;
    log4js: any;
    tslib: any;
    'socket.io': any;
    'msgpack-lite': any;
};
export default _default;
